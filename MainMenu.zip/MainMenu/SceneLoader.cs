using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    public void LoadSceneLevel1()
    {
        SceneManager.LoadScene("MainGame");
    }
    public void LoadSceneLevel2()
    {
        SceneManager.LoadScene("Master Dung");
    }

    public void LoadNextInBuild()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
