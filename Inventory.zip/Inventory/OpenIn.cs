using UnityEngine;

public class OpenIn : MonoBehaviour
{
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            if (isOpen)
            {
                CloseInventory();
            }
            else
            {
                InventoryOn();
            }
        }
    }
    public GameObject Inventory;

    private bool isOpen = false;
    public void InventoryOn()
    {
        Inventory.SetActive(true);
        isOpen = true;
    }

    public void CloseInventory()
    {
        Inventory.SetActive(false);
        isOpen = false;
    }
}
